# NetworkBuster OS Build

A self-contained, portable browser workspace assembled from the published LunaRecycle application and the supplied public NetworkBuster web programs.

## Important scope

This package is a **portable browser OS/application environment**, not a bootable operating-system ISO. It does not flash or modify physical disks. Any device imaging, registration, or flash operation must remain local and explicitly approved by the user.

## Launch

```powershell
powershell -ExecutionPolicy Bypass -File .\launch.ps1
```

The launcher binds only to `127.0.0.1`, opens the packaged site in a browser, and stops with Ctrl+C. Use `-NoBrowser` to suppress browser launch or `-Port 8125` to select a port.

## Build

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

Output: `build\networkbuster-os.zip`.

The build creates `MANIFEST.json` with a SHA-256 digest for every packaged file. It excludes the output directory and generated local collections.

## Included

- LunaRecycle landing page, launchpad, documentation, and history
- NetworkBuster admin/device workflow
- Imported NetworkBuster web-program suite
- HTML fetch and program-import tool
- Offline Node.js/Python static server launcher
- Import, registration, clone-command, and safe flash-preparation workflow

## Security

- No cloud credentials, `.env` values, security session data, Git metadata, or dependency directories are packaged.
- Review `MANIFEST.json` before redistribution.
- Imported APIs may require a separately configured backend.

[CmdletBinding()]
param([string]$Output)

$ErrorActionPreference = 'Stop'
if (-not $Output) { $Output = Join-Path $PSScriptRoot 'build\networkbuster-os.zip' }
$manifestPath = Join-Path $PSScriptRoot 'MANIFEST.json'
$files = @(Get-ChildItem $PSScriptRoot -Recurse -File | Where-Object {
    $_.FullName -notlike (Join-Path $PSScriptRoot 'build\*') -and $_.Name -ne 'MANIFEST.json'
} | ForEach-Object {
    $relative = $_.FullName.Substring($PSScriptRoot.Length).TrimStart('\')
    $hash = Get-FileHash $_.FullName -Algorithm SHA256
    [pscustomobject]@{ path = $relative.Replace('\', '/'); bytes = $_.Length; sha256 = $hash.Hash.ToLowerInvariant() }
} | Sort-Object path)

$manifest = [ordered]@{
    build = 'networkbuster-os'
    version = '1.0.0'
    type = 'portable-browser-os'
    bootable = $false
    createdUtc = (Get-Date).ToUniversalTime().ToString('o')
    source = 'LunaRecycle main deployment plus imported public web programs'
    fileCount = $files.Count
    files = $files
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding UTF8

New-Item -ItemType Directory (Split-Path $Output -Parent) -Force | Out-Null
if (Test-Path $Output) { Remove-Item $Output -Force }
$staging = Join-Path $env:TEMP ("networkbuster-os-stage-" + [guid]::NewGuid())
New-Item -ItemType Directory $staging | Out-Null
try {
    Copy-Item (Join-Path $PSScriptRoot '*') $staging -Recurse -Force -Exclude 'build'
    Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $Output -CompressionLevel Optimal
}
finally {
    Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host "Built $Output" -ForegroundColor Green
Get-Item $Output | Select-Object FullName, Length, LastWriteTime

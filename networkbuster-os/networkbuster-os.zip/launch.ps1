[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 8000,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$webRoot = Join-Path $PSScriptRoot 'payload\web'
if (-not (Test-Path (Join-Path $webRoot 'index.html'))) {
    throw "Build payload is missing: $webRoot"
}

$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    $command = $python.Source
    $arguments = @('-m', 'http.server', $Port, '--bind', '127.0.0.1', '--directory', $webRoot)
}
else {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) { throw 'Install Python 3 or Node.js 20+ to launch the build.' }
    $server = Join-Path $PSScriptRoot 'tools\server.mjs'
    $env:NETWORKBUSTER_PORT = $Port
    $env:NETWORKBUSTER_ROOT = $webRoot
    $command = $node.Source
    $arguments = @($server)
}

$url = "http://127.0.0.1:$Port/"
if (-not $NoBrowser) { Start-Process $url }
Write-Host "NetworkBuster OS build: $url" -ForegroundColor Cyan
Write-Host 'Press Ctrl+C to stop.' -ForegroundColor Yellow
& $command @arguments

import http from 'node:http';
import { createReadStream, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';

const root = resolve(process.env.NETWORKBUSTER_ROOT || 'payload/web');
const port = Number(process.env.NETWORKBUSTER_PORT || 8000);
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon' };
const server = http.createServer((request, response) => {
  let path;
  try {
    const raw = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    path = resolve(join(root, normalize(raw).replace(/^[/\\]+/, '')));
    if (!path.startsWith(root + '\\') && path !== root) throw new Error('outside root');
    let stats = statSync(path);
    if (stats.isDirectory()) { path = join(path, 'index.html'); stats = statSync(path); }
    if (!stats.isFile()) throw new Error('not a file');
    response.writeHead(200, { 'content-type': types[extname(path).toLowerCase()] || 'application/octet-stream', 'x-content-type-options': 'nosniff', 'cache-control': 'no-store' });
    createReadStream(path).pipe(response);
  } catch {
    response.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    response.end('Not found');
  }
});
server.listen(port, '127.0.0.1', () => console.log(`NetworkBuster OS build: http://127.0.0.1:${port}/`));
